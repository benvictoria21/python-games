# facebook-messenger-bot
A demo fb messenger bot

This repository contains the code used in the tutorial series: [Facebook messenger bot tutorial](https://www.youtube.com/playlist?list=PLyb_C2HpOQSC4M3lzzrql7DSppTeAxh-x)

